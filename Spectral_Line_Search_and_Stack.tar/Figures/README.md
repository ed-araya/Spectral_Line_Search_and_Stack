# Plots of spectral data

## Configuration and requirements

- Anaconda 

- Libraries:
- numpy and matplolib


### 
